package flap;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.event.*;// * used to be ActionListener, I don't even understand how this fixes the problem, but it does. 
import java.awt.Graphics;
public class Flap implements ActionListener{
  public static Flap flap;
  public final int WIDTH=1080, HEIGHT=720;
  public Renderer renderer;
  
  public Flap(){
    JFrame jframe = new JFrame();
    Timer timer = new Timer(20, this);
    renderer = new Renderer();
    jframe.add(renderer);
    jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);
    jframe.setSize(WIDTH,HEIGHT);
    jframe.setResizable(false);
    jframe.setVisible(true);
    
    timer.start();
  }
  
  public void actionPerformed(ActionEvent e){
    renderer.repaint();
  }
  
  
  public void repaint(Graphics g){
    System.out.println("Hello");
  }
  
  
  public static void main(String[] args) {
   flap = new Flap(); 
  }
  
}
